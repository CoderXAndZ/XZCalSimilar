//
//  ViewController.swift
//  XZCalSimilarSwift
//
//  Created by mac on 2018/9/11.
//  Copyright © 2018年 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // "GGATCGA" "初始化第一列"
        let str1 = "初始化第一列"
        // "GAATTCAGTTA" "初始化第一行"
        let str2 = "初始化第一行"
        
        let similar = calSimilar(str1: str1, str2: str2)
        
        print("\n similar",similar)
    }
    
    //  计算编辑距离
    func calDistance(str1: String,str2: String) -> Float {
        let len1 = str1.count
        let len2 = str2.count
        
        if len1 == 0 { return Float(len2) }
        if len2 == 0 { return Float(len1) }
        
        // 初始化一个len1 * len2 的二维数组
        var d = [Array<Int>]()
        
        for _ in 0...len1 {
            
            var array = [Int]()
            
            for j in 0...len2 {
                array.append(j)
            }
            d.append(array)
        }
        
        print("初始化的二维数组：",d)
        
        var eq = 0
        var char1: String, char2: String
        
        for i in 1...len1 {
            char1 = (str1 as NSString).substring(with: NSRange(location: i-1, length: 1))
            for j in 1...len2 {
                char2 = (str2 as NSString).substring(with: NSRange(location: j-1, length: 1))
                
                if char1 == char2 {
                    eq = 0
                }else {
                    eq = 1
                }
                d[i][j] = min(min(d[i-1][j] + 1, d[i][j-1] + 1),d[i-1][j-1] + eq)
            }
        }
        
        print("\n 计算编辑距离：",d)
        return Float(d[len1][len2])
    }
    
    // 计算相似度
    func calSimilar(str1: String?, str2: String?) -> Float {
       guard let str1 = str1,
        let str2 = str2
        else { return 0.0 }
        
        let distance = calDistance(str1: str1, str2: str2)
        print("\n distance", distance)
        
        return 1 - distance / Float(max(str1.count, str2.count))
    }
}






