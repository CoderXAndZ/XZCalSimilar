//
//  ViewController.m
//  XZCalSimilar
//
//  Created by mac on 2018/9/11.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *str1 = @"GGATCGA";// @"GGATCGA"; @"初始化第一列";
    NSString *str2 = @"GAATTCAGTTA";//@"GAATTCAGTTA"; @"初始化第一行";
    
    CGFloat similar = [self calSimilar:str1 str2:str2];
    NSLog(@"%f",similar);
}

//  计算编辑距离
- (CGFloat)calDistance:(NSString *)str1 str2:(NSString *)str2 {
    
    int len1 = (int)str1.length;
    int len2 = (int)str2.length;
    
    if (len1 == 0) { return len2;}
    if (len2 == 0) { return len1;}
    
    // 初始化一个len1 * len2 的二维数组
    NSMutableArray *d = [NSMutableArray array];
    for (int i = 0; i <= len1; i++) { // i = 0，初始化第一列
        NSMutableArray *array = [NSMutableArray array];
        for (int j = 0; j <= len2; j++) { // j = 0，初始化第一行
            [array addObject:@(j)];
        }
        [d addObject:array];
    }
    
//    for (int i = 0; i <= len1; i++) { // 初始化第一列
//        // d[i][0]
//        d[i][0] = @(i);
//    }
//
//    for (int j = 0; j <= len2; j++) { // 初始化第一行
//        // d[0][j]
//        d[0][j] = @(j);
//    }
    
    NSLog(@"初始化的二维数组：%@",d);
    
    int eq = 0;
    NSString *char1, *char2;
    
    for (int i = 1; i <= len1; i++) {
        char1 = [str1 substringWithRange:NSMakeRange(i-1, 1)];

        for (int j = 1; j <= len2; j++) {
            char2 = [str2 substringWithRange:NSMakeRange(j-1, 1)];

            if ([char1 isEqualToString: char2]) {
                eq = 0;
            }else {
                eq = 1;
            }
            d[i][j] = @(MIN(MIN([d[i-1][j] intValue] + 1, [d[i][j-1] intValue]+1),[d[i-1][j-1] intValue] + eq));
        }
    }
    
    NSLog(@"\n\n\n ====== %@",d);
    NSLog(@"d[len1][len2] intValue: %d",[d[len1][len2] intValue]);
    return [d[len1][len2] floatValue];
}

// 计算相似度
- (CGFloat)calSimilar:(NSString *)str1 str2:(NSString *)str2 {
    if (str1 == NULL || str2 == NULL || str1.length == 0 || str2.length == 0) {
        return 0;
    }
    
    CGFloat distance = [self calDistance: str1 str2: str2];
    NSLog(@"\n 计算相似度：%f",distance);
    NSLog(@"\n str1.length：%lu",(unsigned long)str1.length);
    NSLog(@"\n str2.length：%lu",(unsigned long)str2.length);
    
    NSLog(@"\n MAX：%lu",(unsigned long)MAX(str1.length, str2.length));
    
    return 1 - distance / MAX(str1.length, str2.length);
}


@end
